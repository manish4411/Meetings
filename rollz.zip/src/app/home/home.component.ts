import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { UserService } from '../user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  meetings:any[]=[];
  searchbtn:boolean = false
tabs :any[]= [
  {name:"Aaaaa"},
  {name:"Bbbbb"},
  {name:"Ccccc"},
  {name:"Ddddd"},
  {name:"Eeeee"},
  {name:"Fffff"},
  {name:"Gggggg"},
  {name:"Hhhhhh"},
  {name:"Hhhhhh"},
]
  constructor(private userService : UserService) { }

  ngOnInit() {
    this.allMeetings();
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });

  }
  search(){
    this.searchbtn = true;
  }
  searchClose(){
    this.searchbtn = false;
  }
  allMeetings(){
    this.userService.getMeetings().subscribe(response =>{
this.meetings = response['result'][0]['meetingList'];

debugger
    })
  }

}
