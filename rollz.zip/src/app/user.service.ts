import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor( private http : HttpClient) { }
  getMeetings(): Observable <any>{
    return this.http.get('http://172.105.33.239:3300/api/meetings/meetinglist?ownerUserId=12')
    }
    getMeetingDetails():Observable<any>{
      return this.http.get('http://172.105.33.239:3300/api/meetings/meetingDetails?meetingID=12&sessionID=123')
    }
}

