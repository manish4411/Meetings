import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MeetingsComponent } from './meetings/meetings.component';
import { NotificationComponent } from './notification/notification.component';
import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';
import { MeetingDetailsComponent } from './meeting-details/meeting-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MeetingsComponent,
    NotificationComponent,
    MeetingDetailsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
    
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
