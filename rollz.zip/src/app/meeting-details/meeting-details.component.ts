import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-meeting-details',
  templateUrl: './meeting-details.component.html',
  styleUrls: ['./meeting-details.component.css']
})
export class MeetingDetailsComponent implements OnInit {
  details:any[]=[];
  officers:any[]=[];
  participents:any[]=[];
  moderatorDetails:any[]=[];
  documents:any[]=[];
  minutes:any[]=[];
  searchbtn;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.meetingDetails("as")
  }
  search(){
    this.searchbtn = true;
  }
  searchClose(){
    this.searchbtn = false;
  }
  meetingDetails(index){
    this.userService.getMeetingDetails().subscribe(response =>{
      this.details = response['result'][0]['meetingDetails'];
     this.officers = response['result'][0]['meetingDetails'].Officers;
     this.participents = response['result'][0]['meetingDetails'].Participents;
     this.documents = response['result'][0]['meetingDetails'].Documents;
     this.minutes = response['result'][0]['meetingDetails'].mom
this.moderatorDetails = response['result'][0]['meetingDetails'].moderator[0];
      debugger
    })
      }
}
